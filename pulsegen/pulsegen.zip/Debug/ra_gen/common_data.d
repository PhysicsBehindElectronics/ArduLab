ra_gen/common_data.o: ../ra_gen/common_data.c ../ra_gen/common_data.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/bsp_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/fsp_common_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/fsp_version.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_gen/bsp_clock_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_override.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_mcu_info.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_elc.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_feature.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_peripheral.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/board_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_gen/vector_data.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_exceptions.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/renesas.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/R7FA4M1AB.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm4.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_mpu.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_common.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/api/fsp_common_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_compiler_support.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_tfu.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_sdram.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mmf.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ipc.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ospi_b.h \
 bsp_linker_info.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_register_protection.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_irq.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_io.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_group_irq.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_clocks.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_module_stop.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_security.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/fsp_features.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/fsp_common_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/../../fsp/src/bsp/mcu/all/bsp_compiler_support.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_delay.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mcu_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/instances/r_ioport.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/r_ioport_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/bsp_api.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/r_ioport_cfg.h \
 /home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h
../ra_gen/common_data.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/bsp_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/fsp_common_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/fsp_version.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_gen/bsp_clock_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_family_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_pn_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_device_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_override.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_mcu_info.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_elc.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_feature.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/../../../ra/fsp/src/bsp/mcu/ra4m1/bsp_peripheral.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_mcu_ofs_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/board_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_gen/vector_data.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_exceptions.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/renesas.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_gcc.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/R7FA4M1AB.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/core_cm4.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_version.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/cmsis_compiler.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/arm/CMSIS_6/CMSIS/Core/Include/m-profile/armv7m_mpu.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/cmsis/Device/RENESAS/Include/system.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_common.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/api/fsp_common_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_compiler_support.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_tfu.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_sdram.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mmf.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ipc.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_ospi_b.h:
bsp_linker_info.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_register_protection.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_irq.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_io.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_group_irq.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_clocks.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_module_stop.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_security.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/fsp_features.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/fsp_common_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../inc/../../fsp/src/bsp/mcu/all/bsp_compiler_support.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_delay.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/../../src/bsp/mcu/all/bsp_mcu_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/instances/r_ioport.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/r_ioport_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra/fsp/inc/api/bsp_api.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/r_ioport_cfg.h:
/home/mrp/e2_studio/workspace/pulsegen/ra_cfg/fsp_cfg/bsp/bsp_pin_cfg.h:
