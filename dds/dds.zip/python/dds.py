import argparse
import os, sys
import serial

from PyQt6 import QtCore, QtGui, QtWidgets, uic

def send(cmd):
    if debug:
        print(cmd[:-1])
    else:
        dev.write(cmd.encode())
        ans = dev.readline()
    return

def resetcb():
    cmd = 'RS\n'
    send(cmd)
    mainwin.ampsb.setValue(0)
    mainwin.freqsb.setValue(1000.)
    return

def quitcb():
    if not debug:
        dev.close()
    mainwin.destroy()
    app.quit()
    return

def freqcb(freq):
    if 0. <= freq <= 10000.:
        cmd = f'FR{freq:.2f}\n'
        send(cmd)
    return

def ampcb(amp):
    if 0 <= amp <= 2.5:
        ai = int(amp / 2.5 * 1024) 
        cmd = f'AM{ai}\n'
        send(cmd)
    return

def main():
    global app, mainwin, dev, debug

    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--debug', action='store_true')
    parser.add_argument('-p', '--port', help='port name (default /dev/ttyACM0)')
    args = parser.parse_args()
    debug = args.debug is True
    if args.port:
        fname = args.port
    else:
        fname = '/dev/ttyACM0'

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle('Fusion')

    ui_file = "./dds.ui"
    mainwin = uic.loadUi(ui_file)
    mainwin.show()

    mainwin.resetbt.clicked.connect(resetcb)
    mainwin.quitbt.clicked.connect(quitcb)
    mainwin.freqsb.valueChanged.connect(freqcb)
    mainwin.ampsb.valueChanged.connect(ampcb)

    if not debug:
        try:
            dev = serial.Serial(fname)
        except serial.serialutil.SerialException:
            exit(f"Could not open {fname}")
        resetcb()
    
    app.exec()
    
if __name__ == "__main__":
    main()
