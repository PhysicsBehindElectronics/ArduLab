################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../ra/fsp/src/bsp/mcu/ra4m1/bsp_linker.c 

C_DEPS += \
./ra/fsp/src/bsp/mcu/ra4m1/bsp_linker.d 

OBJS += \
./ra/fsp/src/bsp/mcu/ra4m1/bsp_linker.o 

SREC += \
dds.srec 

MAP += \
dds.map 


# Each subdirectory must supply rules for building sources it contributes
ra/fsp/src/bsp/mcu/ra4m1/%.o: ../ra/fsp/src/bsp/mcu/ra4m1/%.c
	$(file > $@.in,-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 -O2 -fmessage-length=0 -fsigned-char -ffunction-sections -fdata-sections -fno-strict-aliasing -Wunused -Wuninitialized -Wall -Wextra -Wmissing-declarations -Wconversion -Wpointer-arith -Wshadow -Wlogical-op -Waggregate-return -Wfloat-equal -g -D_RENESAS_RA_ -D_RA_CORE=CM4 -D_RA_ORDINAL=1 -I"/home/mrp/e2_studio/workspace/dds/ra_gen" -I"." -I"/home/mrp/e2_studio/workspace/dds/ra_cfg/fsp_cfg/bsp" -I"/home/mrp/e2_studio/workspace/dds/ra_cfg/fsp_cfg" -I"/home/mrp/e2_studio/workspace/dds/src" -I"/home/mrp/e2_studio/workspace/dds/ra/fsp/inc" -I"/home/mrp/e2_studio/workspace/dds/ra/fsp/inc/api" -I"/home/mrp/e2_studio/workspace/dds/ra/fsp/inc/instances" -I"/home/mrp/e2_studio/workspace/dds/ra/arm/CMSIS_6/CMSIS/Core/Include" -I"/home/mrp/e2_studio/workspace/dds/ra/fsp/src/r_usb_basic/src/driver/inc" -std=c99 -Wno-stringop-overflow -Wno-format-truncation --param=min-pagesize=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -c -o "$@" -x c "$<")
	@echo Building file: $< && arm-none-eabi-gcc @"$@.in"

